// user.h
#include <string>
using namespace std;

namespace Authenticate {
	void inputUserName();
	string getUserName();
}