// password.h
#include <string>
using namespace std;

namespace Authenticate {
	void inputPassword();
	string getPassword();
}