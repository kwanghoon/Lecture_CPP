// node.cpp

#include "node.h"

Node::Node(int name) {
	this->name = name;
}

