#include <iostream>
#include "Cyberdemon.h"
#include "CyberdemonAuto.h"
using namespace std;

CyberdemonAuto::CyberdemonAuto(int strength, int hitpoints, int x, int y)
	: Cyberdemon(strength, hitpoints, x, y) {
	i = 0;
	this->_strength = strength;
	this->_hitpoints = hitpoints;
	this->_x = x;
	this->_y = y;
}

int CyberdemonAuto::getRand() {
	if (Creature::getAutoplay() == false) {
		int r = Demon::getRand();
		intRands.push_back(r);
		return r;
	}
	else {
		return intRands[i++];
	}
}

void CyberdemonAuto::initializeAutoplay() {
	i = 0;
	this->setStrength(this->_strength);
	this->setHitpoints(this->_hitpoints);
	this->setX(this->_x);
	this->setY(this->_y);
}