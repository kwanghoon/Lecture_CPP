#pragma once
#include <string>
using namespace std;

class Creature {
	int strength;
	int hitpoints;
	int x, y;
	static bool autoplay;
protected:
	virtual int getRand();

public:
	Creature(int stregnth, int hitpoints, int x, int y);
	void setStrength(int strength);
	int getStrength();
	void setHitpoints(int hitpoints);
	int getHitpoints();

	int getX();
	int getY();

	void setX(int x);
	void setY(int y);

	virtual void move(int width, int height);

	static bool getAutoplay();
	static void setAutoplay(bool autoplay);

	virtual void initializeAutoplay();

	virtual string getSpecies();
	virtual int getDamage();
};