#include <string>
#include <iostream>
#include <cstdlib>
#include "Creature.h"
using namespace std;

bool Creature::autoplay = false;

Creature::Creature(int strength, int hitpoints, int x, int y) {
	this->strength = strength;
	this->hitpoints = hitpoints;
	this->x = x;
	this->y = y;
	autoplay = false;
}

void Creature::setStrength(int strength) {
	this->strength = strength;
}

int Creature::getStrength() {
	return this->strength;
}

void Creature::setHitpoints(int hitpoints) {
	this->hitpoints = hitpoints;
}

int Creature::getHitpoints() {
	return this->hitpoints;
}

int Creature::getX() { return this->x; }

int Creature::getY() { return this->y; }

void Creature::setX(int x) { this->x = x; }

void Creature::setY(int y) { this->y = y; }

bool Creature::getAutoplay() { return Creature::autoplay;  }

void Creature::setAutoplay(bool autoplay) { Creature::autoplay = autoplay;  }

void Creature::move(int width, int height) {
	int direction = getRand() % 4 + 1; // 1(up), 2(down), 3(left), 4(right)
	int steps = getRand() % 3; // 0, 1, 2 steps

	int newx = getX();
	int newy = getY();

	int deltax = 0;
	int deltay = 0;

	if (direction == 1) deltay = -1;
	else if (direction == 2) deltay = 1;
	else if (direction == 3) deltax = -1;
	else if (direction == 4) deltax = 1;

	newx = newx + deltax * steps;
	newy = newy + deltay * steps;

	if (newx < 0) newx = 0;
	else if (newx >= width) newx = width - 1;

	if (newy < 0) newy = 0;
	else if (newy >= height) newy = height - 1;

	cout << this->getSpecies() << " moves from "
		<< this->getX() << "," << this->getY()
		<< " to " << newx << "," << newy << endl;

	this->setX(newx);
	this->setY(newy);
}

string Creature::getSpecies() {
	return "Unknown Creature";
}

int Creature::getDamage() {
	int damage;

	damage = getRand() % strength + 1;
	cout << getSpecies() << " attacks for "
		<< damage << " points!" << endl;

	return damage;
}

void Creature::initializeAutoplay() { }

int Creature::getRand() {
	return rand();
}
