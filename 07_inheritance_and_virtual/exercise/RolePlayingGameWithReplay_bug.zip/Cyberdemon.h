#pragma once
#include <string>
#include "Demon.h"

using namespace std;

class Cyberdemon : public Demon {
	virtual string getSpecies();
public:
	Cyberdemon(int strength, int hitpoints, int x, int y);
	virtual int getDamage();
};
