#include <string>
#include <iostream>
#include <cstdlib>
#include "Cyberdemon.h"
#include "Demon.h"

using namespace std;

Cyberdemon::Cyberdemon(int strength, int hitpoints, int x, int y)
	: Demon(strength, hitpoints, x, y) { }

string Cyberdemon::getSpecies() {
	return "Cyberdemon";
}

int Cyberdemon::getDamage() {
	int damage;

	damage = Demon::getDamage();
	return damage;
}
