#pragma once
#include <vector>
#include "Cyberdemon.h"
using namespace std;

class CyberdemonAuto : public Cyberdemon {
	vector<int> intRands;
	int i;

	int _strength;
	int _hitpoints;
	int _x, _y;
protected:
	virtual int getRand();

public:
	CyberdemonAuto(int strength, int hitpoints, int x, int y);
	virtual void initializeAutoplay();
};