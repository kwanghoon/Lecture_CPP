#pragma once
#include <string>
#include "Creature.h"

using namespace std;

class Elf : public Creature {
	virtual string getSpecies();
protected:
	virtual int getRand();
public:
	Elf(int strength, int hitpoints, int x, int y);
	virtual int getDamage();
};