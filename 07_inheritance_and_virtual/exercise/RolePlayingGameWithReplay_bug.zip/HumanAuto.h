#pragma once
#include <vector>
#include "Human.h"
using namespace std;

class HumanAuto : public Human {
	vector<string> inputs;
	int i;

	int _strength;
	int _hitpoints;
	int _x, _y;
protected:
	virtual string getInput();
public:
	HumanAuto(int strength, int hitpoints, int x, int y);

	virtual void initializeAutoplay();
};