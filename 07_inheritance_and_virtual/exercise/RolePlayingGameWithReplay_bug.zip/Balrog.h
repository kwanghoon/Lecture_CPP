#pragma once
#include <string>
#include "Demon.h"

using namespace std;

class Balrog : public Demon {
	virtual string getSpecies();
protected:
	virtual int getRand();
public:
	Balrog(int strength, int hitpoints, int x, int y);
	virtual int getDamage();
};