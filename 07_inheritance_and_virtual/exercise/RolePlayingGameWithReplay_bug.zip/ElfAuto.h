#pragma once
#include <vector>
#include "Elf.h"
using namespace std;

class ElfAuto : public Elf {
	vector<int> randInts;
	int i;

	int _strength;
	int _hitpoints;
	int _x, _y;
protected:
	virtual int getRand();

public:
	ElfAuto(int strength, int hitpoints, int x, int y);
	virtual void initializeAutoplay();
};