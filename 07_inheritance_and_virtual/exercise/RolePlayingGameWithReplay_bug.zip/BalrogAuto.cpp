#include <iostream>
#include "Balrog.h"
#include "BalrogAuto.h"
using namespace std;

BalrogAuto::BalrogAuto(int strength, int hitpoints, int x, int y)
	: Balrog(strength, hitpoints, x, y) {
	i = 0;
	this->_strength = strength;
	this->_hitpoints = hitpoints;
	this->_x = x;
	this->_y = y;
}

void BalrogAuto::initializeAutoplay() {
	i = 0;
	this->setStrength(this->_strength);
	this->setHitpoints(this->_hitpoints);
	this->setX(this->_x);
	this->setY(this->_y);
}

int BalrogAuto::getRand() {
	if (Creature::getAutoplay() == false) {
		int r = Balrog::getRand();
		intRands.push_back(r);
		return r;
	}
	else {
		return intRands[i++];
	}
}