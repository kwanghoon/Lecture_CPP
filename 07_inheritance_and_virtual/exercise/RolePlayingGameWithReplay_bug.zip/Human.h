#pragma once
#include <string>
#include "Creature.h"

using namespace std;

class Human : public Creature {
	virtual string getSpecies();
protected:
	virtual string getInput();
public:
	Human(int strength, int hitpoints, int x, int y);
	virtual void move(int width, int height);
	virtual int getDamage();
};