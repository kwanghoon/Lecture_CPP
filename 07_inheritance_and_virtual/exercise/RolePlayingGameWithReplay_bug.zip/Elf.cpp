#include <string>
#include <iostream>
#include <cstdlib>
#include "Elf.h"
#include "Creature.h"

using namespace std;

Elf::Elf(int strength, int hitpoints, int x, int y)
	: Creature(strength, hitpoints, x, y) { }

string Elf::getSpecies() {
	return "Elf";
}

int Elf::getDamage() {
	int damage;

	damage = Creature::getDamage();

	if (this->getRand() % 10 == 0) {
		cout << "Magical attack inflicts " << damage <<
			" additional damage points!" << endl;
		damage = damage * 2;
	}

	return damage;
}

int Elf::getRand() {
	return rand();
}