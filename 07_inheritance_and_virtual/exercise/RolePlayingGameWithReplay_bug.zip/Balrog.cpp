#include <string>
#include <iostream>
#include <cstdlib>
#include "Balrog.h"
#include "Demon.h"

using namespace std;

Balrog::Balrog(int strength, int hitpoints, int x, int y)
	: Demon(strength, hitpoints, x, y) { }

string Balrog::getSpecies() {
	return "Balrog";
}

int Balrog::getDamage() {
	int damage;

	damage = Demon::getDamage();

	int damage2 = getRand() % getStrength() + 1;
	cout << "Balrog speed attack inflicts " << damage2 <<
		" additional damage points!" << endl;

	damage = damage + damage2;

	return damage;
}

int Balrog::getRand() {
	return rand();
}