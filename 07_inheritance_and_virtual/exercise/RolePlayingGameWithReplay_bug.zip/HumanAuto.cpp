#include <iostream>
#include "Human.h"
#include "HumanAuto.h"
using namespace std;

HumanAuto::HumanAuto(int strength, int hitpoints, int x, int y)
	: Human(strength, hitpoints, x, y) {
	i = 0;
	this->_strength = strength;
	this->_hitpoints = hitpoints;
	this->_x = x;
	this->_y = y;
}

void HumanAuto::initializeAutoplay() {
	i = 0;
	this->setStrength(this->_strength);
	this->setHitpoints(this->_hitpoints);
	this->setX(this->_x);
	this->setY(this->_y);
}

string HumanAuto::getInput() {
	if (Creature::getAutoplay() == false) {
		string input = Human::getInput();
		inputs.push_back(input);
		return input;
	}
	else {
		return inputs[i++];
	}
}