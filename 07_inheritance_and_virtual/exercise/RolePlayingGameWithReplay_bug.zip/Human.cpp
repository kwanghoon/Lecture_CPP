#include <string>
#include <iostream>
#include <cstdlib>
#include "Human.h"
#include "Creature.h"

using namespace std;

Human::Human(int strength, int hitpoints, int x, int y)
	: Creature(strength, hitpoints, x, y) { }

string Human::getSpecies() {
	return "Human";
}

int Human::getDamage() {
	int damage;
	damage = Creature::getDamage();
	return damage;
}

void Human::move(int width, int height) {
	cout << "How do you move Human (up/down/left/right/stay)? ";
	string input;
	input = getInput();
	
	int newx = getX();
	int newy = getY();

	int deltax = 0;
	int deltay = 0;

	if (input == "up") deltay = -1;
	else if (input == "down") deltay = 1;
	else if (input == "left") deltax = -1;
	else if (input == "right") deltax = 1;

	newx = newx + deltax;
	newy = newy + deltay;

	if (newx < 0) newx = 0;
	else if (newx >= width) newx = width - 1;

	if (newy < 0) newy = 0;
	else if (newy >= height) newy = height - 1;

	cout << "Human moves from "
		<< this->getX() << "," << this->getY()
		<< " to " << newx << "," << newy << endl;

	this->setX(newx);
	this->setY(newy);
}

string Human::getInput() {
	string input;
	cin >> input;
	return input;
}