#include <string>
#include <iostream>
#include <cstdlib>
#include "Demon.h"
#include "Creature.h"

using namespace std;

Demon::Demon(int strength, int hitpoints, int x, int y)
	: Creature(strength, hitpoints, x, y) { }

string Demon::getSpecies() {
	return "Demon";
}

int Demon::getDamage() {
	int damage;

	damage = Creature::getDamage();

	if (getRand() % 100 < 5) {
		damage = damage + 50;
		cout << "Demonic attack inflicts 50"
			<< " additional damage points!" << endl;
	}
	
	return damage;
}

int Demon::getRand() {
	return rand();
}