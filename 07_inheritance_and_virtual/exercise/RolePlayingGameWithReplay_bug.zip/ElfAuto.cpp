#include <iostream>
#include "ElfAuto.h"
using namespace std;

ElfAuto::ElfAuto(int strength, int hitpoints, int x, int y)
	: Elf(strength, hitpoints, x, y) {
	i = 0;
	this->_strength = strength;
	this->_hitpoints = hitpoints;
	this->_x = x;
	this->_y = y;
}

int ElfAuto::getRand() {
	if (Creature::getAutoplay() == false) {
		int r = Elf::getRand();
		this->randInts.push_back(r);
		return r;
	}
	else {
		return this->randInts[i++];
	}
}

void ElfAuto::initializeAutoplay() {
	i = 0;
	this->setStrength(this->_strength);
	this->setHitpoints(this->_hitpoints);
	this->setX(this->_x);
	this->setY(this->_y);
}